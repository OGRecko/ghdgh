# Final verification status

## Source-level verification completed
- Public/free access: no mandatory login, subscription, payment, checkout, trial, premium, or Polar flow.
- Public solver ceiling: exactly 50,000,000 cells.
- Memory guard: fail-safe environment parsing and pre-allocation admission.
- 64 receiver limit: shared validation and worker enforcement.
- Custom geometry, openings, per-wall materials: validated and propagated through solver/report paths.
- Seven-band boundary path: persistent causal state with explicit 125/250/500/1000/2000/4000/8000 coverage and no fabricated missing coefficients.
- Directivity: validated, orientation-aware, frequency-coverage gated, with frequency interpolation between supplied bins.
- Modal regression: actual FDTD trace spectral analysis against analytical axial modes.
- Artifact storage: production Firebase Cloud Storage implementation; memory backend is test-only.
- Capability-token authorization and cancellation/job fencing remain enabled.
- Canonical version constants are used for release/report metadata.
- Material absorption values have one authoritative per-band source.

## Environment-limited verification
A complete `npm ci`, semantic TypeScript check, full test suite, Vite/server production build, Firebase emulator suite, and `npm audit` require a networked Node 22.23.2+ environment with the project's dependencies available. This execution environment could not complete dependency installation, so those results are not falsely represented as passing.

Run:

```bash
npm ci
npm run verify
npm run audit:final
```

For deployed infrastructure, additionally run the production smoke/deployment verification scripts with the real Firebase/GCP credentials.


## Release-hardening verification
- Static final audit remains required.
- `npm run audit:release` checks duplicate speaker IDs/brand-model pairs and flags unverifiable manufacturer sensitivity claims.
- Full `npm run verify` must be run in a networked Node 22.23.2 environment before a production launch claim.
