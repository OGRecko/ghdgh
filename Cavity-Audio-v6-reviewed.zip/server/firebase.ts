/**
 * Firebase Admin initialisation from validated configuration.
 *
 * There are NO fallbacks here: credentials, project id and bucket all come
 * from loadConfig(), which has already refused to start in production if any
 * of them is missing. Production can also use Google Application Default
 * Credentials (ADC), which is the preferred mode on Cloud Run/GCE. Nothing
 * is read from a checked-in file.
 */
import { applicationDefault, cert, getApps, initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import type { AppConfig } from './config';
import type { FirestoreLike } from './jobStore';
import { FirebaseArtifactStore } from './storage';

export function createFirebase(config: AppConfig): { db: FirestoreLike & { batch(): any }; artifacts: FirebaseArtifactStore } {
  if (getApps().length === 0) {
    if (config.credentials) {
      initializeApp({
        credential: cert({
          projectId: config.credentials.projectId,
          clientEmail: config.credentials.clientEmail,
          privateKey: config.credentials.privateKey,
        }),
        projectId: config.credentials.projectId,
        storageBucket: config.storageBucket ?? undefined,
      });
    } else if (config.useApplicationDefaultCredentials && config.projectId) {
      initializeApp({
        credential: applicationDefault(),
        projectId: config.projectId,
        storageBucket: config.storageBucket ?? undefined,
      });
    } else if (config.useEmulator && config.projectId) {
      initializeApp({ projectId: config.projectId, storageBucket: config.storageBucket ?? undefined });
    } else {
      throw new Error('No Firebase credentials, application-default credentials, or emulator configured.');
    }
  }
  const db = (config.firestoreDatabaseId ? getFirestore(config.firestoreDatabaseId) : getFirestore()) as any;
  const bucketName = config.storageBucket;
  if (!bucketName) throw new Error('No storage bucket configured.');
  return { db, artifacts: new FirebaseArtifactStore(() => getStorage().bucket(bucketName)) };
}
