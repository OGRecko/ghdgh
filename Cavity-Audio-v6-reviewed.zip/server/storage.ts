/**
 * Artifact storage. A small interface with two implementations:
 *   - FirebaseArtifactStore: Cloud Storage via the Admin SDK (production).
 *   - MemoryArtifactStore (server/testing): in-memory, for tests.
 *
 * Authorization lives in artifactAccess.ts, NOT here; this module only moves
 * bytes and validates object identifiers.
 */
import { LIMITS, UUID_RE } from '../src/lib/publicLimits';

export const OBJECT_PREFIX = 'public-simulations/';

const OBJECT_ID_RE = /^([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})_(receiver|wave)_([0-9]{1,6})\.bin$/i;

export class InvalidObjectIdError extends Error { constructor() { super('Invalid object ID'); this.name = 'InvalidObjectIdError'; } }
export class ArtifactTooLargeError extends Error { constructor() { super('Artifact exceeds size limit'); this.name = 'ArtifactTooLargeError'; } }
export class ArtifactNotFoundError extends Error { constructor() { super('Artifact not found'); this.name = 'ArtifactNotFoundError'; } }

export interface ParsedObjectId { simulationId: string; kind: 'receiver' | 'wave'; index: number }

/**
 * Object IDs are `<uuid>_<receiver|wave>_<digits>.bin`, nothing else. The
 * numeric index (not a free-form suffix) makes traversal, encoding tricks and
 * ambiguous prefixes structurally impossible.
 */
export function parseObjectId(objectId: unknown): ParsedObjectId {
  if (typeof objectId !== 'string' || objectId.length > 100) throw new InvalidObjectIdError();
  const m = OBJECT_ID_RE.exec(objectId);
  if (!m || !UUID_RE.test(m[1])) throw new InvalidObjectIdError();
  return { simulationId: m[1].toLowerCase(), kind: m[2].toLowerCase() as 'receiver' | 'wave', index: Number(m[3]) };
}

export const receiverObjectId = (simulationId: string, i: number) => `${simulationId}_receiver_${i}.bin`;
export const waveObjectId = (simulationId: string, i: number) => `${simulationId}_wave_${i}.bin`;

export interface ArtifactStore {
  put(objectId: string, data: Buffer): Promise<void>;
  /** Throws ArtifactNotFoundError / ArtifactTooLargeError. Never buffers an over-limit object. */
  get(objectId: string, maxBytes: number): Promise<Buffer>;
  delete(objectId: string): Promise<void>;
  /** Delete every object belonging to a simulation; returns the number removed. */
  deleteAllForSimulation(simulationId: string): Promise<number>;
  /** Total bytes currently stored for a simulation. */
  sizeForSimulation(simulationId: string): Promise<number>;
}

export class FirebaseArtifactStore implements ArtifactStore {
  constructor(private readonly bucket: () => any) {}

  private file(objectId: string) {
    parseObjectId(objectId);
    return this.bucket().file(`${OBJECT_PREFIX}${objectId}`);
  }

  async put(objectId: string, data: Buffer): Promise<void> {
    await this.file(objectId).save(data, {
      resumable: false,
      contentType: 'application/octet-stream',
      metadata: { cacheControl: 'private, no-store' },
    });
  }

  async get(objectId: string, maxBytes: number): Promise<Buffer> {
    const f = this.file(objectId);
    let meta: any;
    try { [meta] = await f.getMetadata(); }
    catch (e: any) { if (e?.code === 404) throw new ArtifactNotFoundError(); throw e; }
    if (Number(meta?.size) > maxBytes) throw new ArtifactTooLargeError();
    const [buf] = await f.download();
    return buf;
  }

  async delete(objectId: string): Promise<void> {
    await this.file(objectId).delete({ ignoreNotFound: true });
  }

  async deleteAllForSimulation(simulationId: string): Promise<number> {
    if (!UUID_RE.test(simulationId)) throw new InvalidObjectIdError();
    const [files] = await this.bucket().getFiles({ prefix: `${OBJECT_PREFIX}${simulationId}_` });
    await Promise.all(files.map((f: any) => f.delete({ ignoreNotFound: true })));
    return files.length;
  }

  async sizeForSimulation(simulationId: string): Promise<number> {
    if (!UUID_RE.test(simulationId)) throw new InvalidObjectIdError();
    const [files] = await this.bucket().getFiles({ prefix: `${OBJECT_PREFIX}${simulationId}_` });
    return files.reduce((n: number, f: any) => n + Number(f.metadata?.size || 0), 0);
  }
}

export { LIMITS };
