/**
 * Production PDF renderer. Kept separate from api.ts so the API (and its
 * tests) never need PDFKit: the renderer is an injected dependency, and this
 * is the one that wraps the real generator.
 */
import { generateProjectReport } from './reportGenerator';
import { LIMITS } from '../src/lib/publicLimits';
import type { ReportBuildInput } from './reportInput';

export type ReportRenderer = (input: ReportBuildInput) => Promise<Buffer>;

export class ReportTooLargeError extends Error { constructor() { super('Report exceeds size limit'); this.name = 'ReportTooLargeError'; } }
export class ReportTimeoutError extends Error { constructor() { super('Report rendering timed out'); this.name = 'ReportTimeoutError'; } }

const str = (v: unknown, d: string) => (typeof v === 'string' && v ? v : d);
const num = (v: unknown, d: number) => (typeof v === 'number' && Number.isFinite(v) ? v : d);

export const pdfReportRenderer: ReportRenderer = (input) => new Promise<Buffer>((resolve, reject) => {
  let doc: PDFKit.PDFDocument;
  try {
    doc = generateProjectReport({
      projectName: input.projectName,
      roomName: input.roomName,
      room: input.room as any,
      speakers: input.speakers.map((s) => ({
        brand: str(s.brand, 'Speaker'), model: str(s.model, ''), x: num(s.x, 0), y: num(s.y, 0),
      })),
      receivers: input.receivers.map((r, i) => ({ name: str(r.name, `Receiver ${i + 1}`), x: num(r.x, 0), y: num(r.y, 0) })),
      solverResult: input.solverResult as any,
      assumedSnrDb: input.assumedSnrDb,
      simulationId: input.simulationId,
    });
  } catch (e) { return reject(e); }

  const chunks: Buffer[] = [];
  let total = 0;
  let settled = false;
  const done = (fn: () => void) => { if (settled) return; settled = true; clearTimeout(timer); fn(); };
  const timer = setTimeout(() => { done(() => { try { doc.destroy?.(); } catch { /* ignore */ } reject(new ReportTimeoutError()); }); }, LIMITS.REPORT_TIMEOUT_MS);
  (timer as any).unref?.();

  doc.on('data', (c: Buffer) => {
    total += c.length;
    if (total > LIMITS.MAX_REPORT_BYTES) { done(() => { try { doc.destroy?.(); } catch { /* ignore */ } reject(new ReportTooLargeError()); }); return; }
    chunks.push(c);
  });
  doc.on('end', () => done(() => resolve(Buffer.concat(chunks))));
  doc.on('error', (e: Error) => done(() => reject(e)));
  // generateProjectReport deliberately does not end the document; ending is the caller's job, exactly once.
  doc.end();
});
