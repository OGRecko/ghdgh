/**
 * Composition root. All request handling lives in server/api.ts; this file
 * only wires configuration, Firebase, the dispatcher and Express together.
 *
 * Production fails fast: loadConfig() throws on any missing/weak setting and
 * the process exits before it opens a port.
 */
import crypto from 'node:crypto';
import path from 'node:path';
import express from 'express';
import helmet from 'helmet';
import { Admission } from './server/admission';
import { createApi } from './server/api';
import { runCleanup } from './server/cleanup';
import { ConfigError, loadConfig, type AppConfig } from './server/config';
import { Dispatcher } from './server/dispatcher';
import { CloudTaskDispatcher } from './server/cloudTaskDispatcher';
import { createFirebase } from './server/firebase';
import { JobStore } from './server/jobStore';
import { logError, logEvent, metrics } from './server/observability';
import { pdfReportRenderer } from './server/reportRenderer';
import { createWorkerRunner } from './server/workerRunner';
import { LIMITS } from './src/lib/publicLimits';

function loadConfigOrExit(): AppConfig {
  try {
    return loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      // Messages name the missing/invalid SETTING only; they never contain a secret value.
      console.error(e.message);
    } else {
      console.error('Configuration failed.');
    }
    process.exit(1);
  }
}

const CSP = {
  useDefaults: false,
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    imgSrc: ["'self'", 'data:', 'blob:'],
    mediaSrc: ["'self'", 'blob:'],
    connectSrc: ["'self'"],
    workerSrc: ["'self'", 'blob:'],
    objectSrc: ["'none'"],
    baseUri: ["'self'"],
    frameAncestors: ["'none'"],
    formAction: ["'self'"],
  },
} as const;

async function main() {
  const config = loadConfigOrExit();
  const isProd = config.env === 'production';

  const { db, artifacts } = createFirebase(config);
  const store = new JobStore(db, Date.now, metrics);
  const admission = new Admission(db, config.ipSalt);
  const workerId = `w-${crypto.randomBytes(6).toString('hex')}`;
  const runner = createWorkerRunner();

  const dispatcher = new Dispatcher({
    store,
    maxConcurrent: LIMITS.MAX_CONCURRENT_SOLVER_JOBS,
    executor: {
      store, artifacts, metrics, workerId,
      runSolver: runner,
      log: (event, fields) => logEvent(event, fields),
      onHeartbeat: (rec) => (rec.slotId ? admission.extendSlot(rec.slotId, LIMITS.SOLVER_SLOT_TTL_MS) : Promise.resolve()),
      onFinished: (rec) => admission.releaseSlot(rec.slotId),
    },
    log: (event, fields) => logEvent(event, fields),
    onJobEndedWithoutRun: (rec) => admission.releaseSlot(rec.slotId),
  });

  const cloudTasks = new CloudTaskDispatcher({
    enabled: config.cloudTasks.enabled,
    projectId: config.cloudTasks.projectId!,
    location: config.cloudTasks.location,
    queue: config.cloudTasks.queue,
    targetUrl: config.cloudTasks.targetUrl!,
    dispatchSecret: config.cloudTasks.dispatchSecret!,
  }, config.credentials ? { client_email: config.credentials.clientEmail, private_key: config.credentials.privateKey } : undefined);

  const api = createApi({
    store, artifacts, admission, dispatcher, metrics,
    cloudTasks: cloudTasks.enabled ? cloudTasks : undefined,
    renderReport: pdfReportRenderer,
    cleanup: { store, artifacts, admission, metrics },
    config: { trustProxy: config.trustProxy, cleanupSecret: config.cleanupSecret, allowedOrigin: config.allowedOrigin },
  });

  const app = express();
  app.disable('x-powered-by');
  // Client addresses are resolved by the API itself from TRUST_PROXY; Express's own proxy logic is unused.
  app.set('trust proxy', false);
  app.use(helmet({
    contentSecurityPolicy: isProd ? CSP : false, // Vite's dev middleware injects inline HMR scripts
    crossOriginEmbedderPolicy: false,
  }));

  app.use((req, res, next) => { api(req, res).then((handled) => { if (!handled) next(); }, next); });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { index: false, maxAge: '1h' }));
    app.get('*', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  // Last-resort handler: never echo internals.
  app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    logError('unhandled_request_error', err);
    if (!res.headersSent) res.status(500).json({ error: 'Internal server error.' });
    else res.end();
  });

  const server = app.listen(config.port, '0.0.0.0', () => {
    logEvent('server_started', { port: config.port, env: config.env, workerId });
  });
  // Connection-level timeouts (slow-loris, hung sockets).
  server.headersTimeout = 15_000;
  server.requestTimeout = 60_000;
  server.keepAliveTimeout = 5_000;
  server.maxHeadersCount = 100;

  dispatcher.start();
  void dispatcher.sweepOnce().catch((e) => logError('initial_sweep_failed', e));
  const cleanupTimer = setInterval(() => {
    void runCleanup({ store, artifacts, admission, metrics }).catch((e) => logError('scheduled_cleanup_failed', e));
  }, 60 * 60 * 1000);
  cleanupTimer.unref?.();

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logEvent('shutdown_started', { signal });
    dispatcher.stop();
    server.close();
    // Let in-flight jobs finish briefly; anything left is recovered by another instance after its lease expires.
    const deadline = new Promise<void>((r) => { setTimeout(r, 8_000).unref?.(); });
    void Promise.race([dispatcher.whenIdle(), deadline]).finally(() => process.exit(0));
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (e) => logError('unhandled_rejection', e));
}

main().catch((e) => {
  logError('startup_failed', e);
  process.exit(1);
});
